using JJH._02_Scripts_Systems.EventSystems;
using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerRoutSender : MonoBehaviour
{
    [SerializeField] private EventChannelSO mapEventChannel;

    [SerializeField] private float testRoutRecordTime = 10f; // �׽�Ʈ�� 10�ʵ��� �����
    private float currentTime = 0f;
    private float recordTime = 0f;
    private bool isRecording = false;

    private void Start()
    {
        isRecording = true;
        mapEventChannel.RaiseEvent(MapEvents.PlayerActionEvent.Init("Ž�� ����"));
        SendPlayerPosition();
    }

    private void Update()
    {
        if (isRecording == false) return;

        currentTime += Time.deltaTime;
        recordTime += Time.deltaTime;
        if (recordTime >= testRoutRecordTime)
        {
            mapEventChannel.RaiseEvent(MapEvents.PlayerActionEvent.Init("Ž�� ����"));
            SendPlayerPosition();
            mapEventChannel.RaiseEvent(MapEvents.RoutRecordEndEvent.Init(recordTime)); // ��� ���� �̺�Ʈ
            isRecording = false;
        }
        else if (currentTime >= MapRoutDataSO.RECORD_INTERVAL)
        {
            currentTime = 0f;
            SendPlayerPosition();
        }

        if (Keyboard.current.qKey.wasPressedThisFrame) // �׽�Ʈ �׼� ����
        {
            SendPlayerAction();
        }
    }

    private void SendPlayerAction()
    {
        mapEventChannel.RaiseEvent(MapEvents.PlayerActionEvent.Init("�׽�Ʈ �׼��� �ߵ��Ǿ����ϴ�."));
        Debug.Log("PlayerRoutSender: �׽�Ʈ �׼��� �ߵ��Ǿ����ϴ�.");
    }

    private void SendPlayerPosition()
    {
        mapEventChannel.RaiseEvent(MapEvents.PlayerPointEvent.Init(transform.position));
        Debug.Log($"PlayerRoutSender: ���� ��ġ�� �����߽��ϴ�. ��ġ: {transform.position}");
    }
}
