using JJH._02_Scripts.Systems.ObjectPoolSystems;
using Unity.AppUI.Core;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(Collider))]
public class Warhead : PoolableMono, IProjectile // ����ī ź��
{
    [SerializeField] private PoolManagerSO poolManager;
    [SerializeField] private PoolItemSO explosionPref;
    [SerializeField] private LayerMask layerMask;
    private Rigidbody body;
    private Collider collider;

    private void Awake()
    {
        body = GetComponent<Rigidbody>();
        collider = GetComponent<Collider>();
    }

    public void Fire(Vector3 dir, float speed)
    {
        dir.Normalize();

        body.linearVelocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;

        body.linearVelocity = dir * speed;

        Debug.Log("�߻� ����");
    }

    private void OnHit() // ���⼭ ���� ó��
    {
        body.linearVelocity = Vector3.zero;

        ExplosionPrefab effect = poolManager.Pop<ExplosionPrefab>(explosionPref);
        effect.transform.position = transform.position;
        effect.Active(5f, 50f, layerMask);

        poolManager.Push(this);

    }

    private void OnTriggerEnter(Collider other)
    {
        OnHit();
    }
}
