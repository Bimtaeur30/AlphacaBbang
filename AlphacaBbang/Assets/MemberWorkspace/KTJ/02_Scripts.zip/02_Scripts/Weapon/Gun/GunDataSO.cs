using UnityEngine;
using UnityEngine.UI;

public enum FireMode
{
    Single, Auto, Spread
}

public enum BulletType
{
    B1, B2, B3
}

[CreateAssetMenu(fileName = "Gun data", menuName = "KTJ/Gun/GunData")]
public class GunDataSO : ScriptableObject
{
    [Header("FireMode")]
    [field: SerializeField] public FireMode FireMode { get; private set; }

    [Header("Bullet")]
    [field:SerializeField] public BulletType BulletType { get; private set; } // �Ѿ� Ÿ��
    [field:SerializeField] public int MagCapacity{ get; private set; } // źâ �뷮

    [Header("Fire")]
    [field: SerializeField, Range(0.05f, 1.0f)] public float FireInterval { get; private set; } = 0.1f; // �߻� ���� ��

    [Header("Durability")]
    [field: SerializeField, Range(50, 200)] public int Durability { get; private set; } = 50; // ������

    [Header("RecoilX")]
    [field: SerializeField, Range(0f, 100f)] public float RecoilForceX { get; private set; } = 1f; // �ݵ�

    [Header("RecoilY")]
    [field: SerializeField, Range(0f, 100f)] public float RecoilForceY { get; private set; } = 1f; // �ݵ�

    [Header("Accuracy")]
    [field: SerializeField, Range(1f, 100f)] public float SpreadAngle { get; private set; } = 1f; // ź ����(��������)

    [Header("Accuracy")]
    [field: SerializeField, Range(1f, 10f)] public int BulletFireCount { get; private set; } = 1; // �ѹ��� ������ �� ����(��������)

    [Header("UI")]
    [field: SerializeField] public Sprite CrossHairSprite { get; private set; } // ���� �̹���
}
