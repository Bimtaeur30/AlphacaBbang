using JJH._02_Scripts.Systems.ObjectPoolSystems;
using UnityEngine;

public class SimpleGun : Gun
{
    [Header("Etc")]
    [SerializeField] private ParticleSystem BulletShellParticle;
    protected override void OnFire(Vector3 origin, Vector3 direction)
    {
        // �ʿ��ϸ� ���⼭ �ѱ� ȭ��, ź�� ����, ���� ���� �� ó��
        // ��:
        // PlayMuzzleFlash();
        // PlayFireSound();
        BulletShellParticle.Play();
    }

    protected override void OnHit(RaycastHit hit)
    {
        if (poolManager == null || bulletParticle == null)
            return;

        PoolParticleEffect effect = poolManager.Pop<PoolParticleEffect>(bulletParticle);
        effect.PlayClipEffect(hit.point, Quaternion.LookRotation(hit.normal));
    }

    protected override void OnMiss(Vector3 origin, Vector3 endPoint)
    {
    }
}